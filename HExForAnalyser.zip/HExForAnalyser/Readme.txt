Attached a hex for quick upload and use. This can be done using 
http://xloader.russemotto.com/ (no worries on libraries etc )

Free for non commercial use. Otherwise contact me

Wiring
=====

Arduino promini (3.3v) is used and it will work in any atmega328 based 
boards
Pin 3 and 2 are connected to rotary encoder
Analogue A1 to reverse from the opamp/bridge
Analogue A2 to Forward from the opamp/bridge

AD9850 (9, 8, 7, 10) goes to( int CLK, int FQUP, int BitData, int RESET)

For TFT connection check the article on blog.riyas.org


